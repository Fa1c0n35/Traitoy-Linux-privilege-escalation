package payloads

type Payload string

var Default Payload = "/bin/sh"
var Defer Payload