package version

var Version string = "v0.0.0"
