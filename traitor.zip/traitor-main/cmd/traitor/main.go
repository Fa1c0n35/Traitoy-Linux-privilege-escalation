package main

import (
	"github.com/liamg/traitor/internal/cmd"
)

func main() {
	cmd.Execute()
}
